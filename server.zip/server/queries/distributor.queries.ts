export default {
    verify: "UPDATE "
};