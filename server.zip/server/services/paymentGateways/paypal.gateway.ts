// import { TenantOrder } from '@/types/tenant.types';
// import { UserOrder } from '@/types/user.types';

// export const init_pp = (clientId: string, clientSecret: string) => {

// };

// export const createOrder = (order: UserOrder | TenantOrder) => {

// };

// export const generateClientToken = () => {

// };