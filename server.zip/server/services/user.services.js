"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchAll = void 0;
const fetchAll = () => {
};
exports.fetchAll = fetchAll;
