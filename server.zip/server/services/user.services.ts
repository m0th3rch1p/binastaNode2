import { execQuery } from "@/helpers/queryHelpers";

export const fetchAll = () => {
    
}