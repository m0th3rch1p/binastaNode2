export const makeRef = (length: number) => {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    
    return result;
}

export const slugify = (str: string) => {
    return str.split(" ").join("-");
}

export const pluralize = (s: string) => {
  s = s.toLowerCase();
  let pluralizedForm = "";
  if (!s) {
    return null;
  }

  if (s.endsWith("ies") || s.endsWith("es") || (!s.endsWith("ws") && s.endsWith("s"))) {
    return s;
  }

  if (s.endsWith("y") && !s.endsWith("ay")) {
    pluralizedForm = s.substring(0, s.length - 1) + "ies";
  } else if (s.endsWith("ws")) {
    pluralizedForm = s + "es";
  } else pluralizedForm = s + "s";

  return pluralizedForm;
};