export type PaypalPurchaseUnits = {
    amount: {
        "current_code": string,
        value: string
    },
    description: string
};