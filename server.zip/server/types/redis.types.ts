export type RedisConfigOptions = {
    host: string,
    port: number,
    username: string,
    password: string
};